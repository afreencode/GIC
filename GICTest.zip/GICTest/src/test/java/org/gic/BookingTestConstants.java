package org.gic;

public class BookingTestConstants {

    public static char BULLET = '\u2022';

    public static char WHITECIRCLE = '\u25CB';

}
